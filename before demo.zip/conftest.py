pytest_plugins = [
    "rental.tests.fixtures",
    "rental.tests.selenium",
    "rental.tests.factories",

]
