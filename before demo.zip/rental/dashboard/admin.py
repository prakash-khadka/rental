from django.contrib import admin
from rental.inventory.models import Category


admin.site.register(Category)

